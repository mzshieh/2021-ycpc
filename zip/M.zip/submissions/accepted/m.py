E, W, S = [float(x) for x in input().strip().split()]
print('%.10f' % (E * W / S))
